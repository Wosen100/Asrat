const express = require('express');
const path  =require('path')
const dotenv = require('dotenv');


const User = require('./models/User')

const serverApp = express();

dotenv.config({path:'./config/config.env'})
const connectDB = require('./config/db.js')



// load env variables


serverApp.use(express.json())

// connect database
connectDB();


serverApp.get('/',function(request,response){
    response.send('hi, I am server')
})

// register usser

serverApp.post('/api/auth/register',async (req,res)=>{

    const newUser = await User.create(req.body);

    if(!newUser){
        res.status(400).json({
            success:false,
            message:'user is not crated'
        })
    }else{

        res.status(200).json({
            success:true,
            data:newUser
        })
    }

})

serverApp.listen(5001,function(){
    console.log('server app is running at PORT: 5000')
})