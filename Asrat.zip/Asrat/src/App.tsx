import React from 'react';


import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Register from './pages/auth/Register';

import Login from './pages/auth/Login';
import Dashboard from './pages/Dashboard';
import DonationEntity from './pages/DonationEntity';
import Donor from './pages/Donor';
import LandingPage from './pages/LandingPage';

export default function App() {
  return (
   <BrowserRouter>

  <Routes>

    <Route path='/landing' element={<LandingPage />} >

    <Route path='signin' element={<Login />} />
    <Route path='signup' element={<Register />} />

    </Route>


    
      

    <Route path='/dashboard' element={<Dashboard />} />
    <Route path='/donation' element={<DonationEntity />} />
    <Route path='/donors' element={<Donor />} />
    
  </Routes>
   </BrowserRouter>
  )
}
