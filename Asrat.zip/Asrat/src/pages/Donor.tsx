import React from "react";


// fetch('http://localhost:5001/api/auth/register')
const Donor = () => {

  
  return <div>Donor</div>;
};

export default Donor;
