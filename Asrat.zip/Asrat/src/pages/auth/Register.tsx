

import React, { useState } from 'react';

const Register = () => {
	const [firstName, setFirstName] = useState('');
	const [lastName, setLastName] = useState('');
	const [email, setEmail] = useState('');
	const [password, setPassword] = useState('');
	const [password2, setPassword2] = useState('');

	const [error, setError] = useState({
		error: false,
		message: '',
	});

	const submitHandler = (event:any) => {
		event.preventDefault();

		if (password !== password2) {
			setError({
				error: true,
				message: 'Both passwords should match',
			});
		}

		const user = {
			firstName,
			lastName,
			email,
			password,
		};

		console.log(user);
	};
	return (
		<div>
			<h3>Sign Up</h3>

			{error.error && <label style={{ color: 'red' }}>{error.message}</label>}
			<div className='form-container'>
				<form onSubmit={submitHandler}>
					<input
						type='text'
						onChange={(e) => setFirstName(e.target.value)}
						placeholder='First Name'
					/>
					<input
						type='text'
						onChange={(e) => setLastName(e.target.value)}
						placeholder='Last Name'
					/>
					<input
						type='email'
						onChange={(e) => setEmail(e.target.value)}
						placeholder='Email'
					/>

					<input
						type='password'
						onChange={(e) => setPassword(e.target.value)}
						placeholder='Password'
					/>
					<input
						type='password'
						onChange={(e) => setPassword2(e.target.value)}
						placeholder='Re Enter Password'
					/>

					<button>Submit</button>
				</form>
			</div>
		</div>
	);
};

export default Register;

