import React, { useState } from 'react';

const Login = () => {
	const [email, setEmail] = useState('');
	const [password, setPassword] = useState('');

	const [error, setError] = useState({
		error: false,
		message: '',
	});

	const submitHandler = (event: any) => {
		const user = {
			email,
			password,
		};
		console.log(user);
	};
    
	return (
		<div>
			<h3>Sign In</h3>

			{error.error && <label style={{ color: 'red' }}>{error.message}</label>}
			<div className='form-container'>
				<form>
					<input
						type='email'
						onChange={(e) => setEmail(e.target.value)}
						placeholder='Email'
					/>

					<input
						type='password'
						onChange={(e) => setPassword(e.target.value)}
						placeholder='Password'
					/>

					<button>Submit</button>
				</form>
			</div>
		</div>
	);
};

export default Login;
