
import React from "react";

const DonationEntity = () => {
  return <div>DonationEntity</div>;
};

export default DonationEntity;
